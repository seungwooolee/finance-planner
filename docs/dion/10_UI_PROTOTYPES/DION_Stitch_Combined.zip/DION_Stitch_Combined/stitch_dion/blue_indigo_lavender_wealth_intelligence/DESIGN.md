---
name: Blue Indigo Lavender Wealth Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d5d9ec'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e3e7fb'
  surface-container-highest: '#dee2f5'
  on-surface: '#161b29'
  on-surface-variant: '#454654'
  inverse-surface: '#2b303e'
  inverse-on-surface: '#eef0ff'
  outline: '#757686'
  outline-variant: '#c5c5d7'
  surface-tint: '#3e4ed4'
  primary: '#3848ce'
  on-primary: '#ffffff'
  primary-container: '#5363e8'
  on-primary-container: '#f9f6ff'
  inverse-primary: '#bdc2ff'
  secondary: '#5e559a'
  on-secondary: '#ffffff'
  secondary-container: '#bcb2ff'
  on-secondary-container: '#4a4285'
  tertiary: '#555965'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e717e'
  on-tertiary-container: '#f7f7ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000a64'
  on-primary-fixed-variant: '#2132bc'
  secondary-fixed: '#e5deff'
  secondary-fixed-dim: '#c8bfff'
  on-secondary-fixed: '#1a0d53'
  on-secondary-fixed-variant: '#463d81'
  tertiary-fixed: '#e0e2f0'
  tertiary-fixed-dim: '#c3c6d4'
  on-tertiary-fixed: '#181b26'
  on-tertiary-fixed-variant: '#434652'
  background: '#faf8ff'
  on-background: '#161b29'
  surface-variant: '#dee2f5'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  number-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
  number-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an intelligent, reassuring, and accessible digital wealth advisory interface. Rooted in modern fintech clarity, it combines institutional financial rigor with an approachable, empathetic digital presence. 

The aesthetic philosophy merges **Modern Corporate Precision** with **Soft Scandinavian Minimalism**:
- **Tone & Mood:** Confident, transparent, composed, and encouraging. It strips away intimidation from complex portfolio mechanics and algorithmic wealth management.
- **Visual Balance:** Cool off-white canvas foundations support crisp pure-white data surfaces. High-contrast typography provides immediate comprehension, while vibrant blue-indigo anchors interactive focus alongside gentle lavender analytical cues.
- **Audience Resonance:** Modern retail investors, high-net-worth individuals, and tech-forward savers seeking institutional-grade advisory without legacy banking friction.

## Colors

The palette establishes cognitive hierarchy, separating active interactive workflows from static financial data.

- **Primary (`#5363E8`):** The primary blue-indigo serves strictly for key interactive elements, primary action buttons, active navigation markers, and decisive trend lines.
- **Secondary (`#B5ABF7`):** Soft lavender functions as a gentle secondary accent for multi-asset charts, allocation distribution graphics, auxiliary interactive tags, and subtle progress metrics.
- **Tertiary / Informational Surface (`#EEF0FF`):** An ultra-soft indigo tint designated for contextual coaching banners, active table rows, selectable container states, and callout callouts.
- **Canvas Neutral (`#F8F9FC`):** A cool-tinted off-white used as the foundation background to prevent screen glare and eye fatigue during prolonged analytical sessions.
- **Card & Data Containers (`#FFFFFF`):** Pure stark white reserved strictly for elevated components, metric cards, transactional tables, and modal dialogues to guarantee maximum contrast against numbers and data visualisations.
- **Text & Contrast Hierarchy:**
  - High-emphasis text, primary values, and headings: `#222735` (Deep Charcoal).
  - Mid-emphasis labels, secondary descriptors, and timestamps: `#667085` (Balanced Slate).
  - Subtle architectural dividers and outlines: `#E5E8F0` (Muted Mist).

## Typography

The typographic engine uses `Plus Jakarta Sans` across all display, body, and operational roles to deliver high legibility alongside rounded modern geometry.

- **Tabular Figures:** All numeric figures, account balances, and table cells must enforce tabular lining features (`tnum` and `lnum`) via OpenType flags to ensure zero-jitter alignment across dynamic market feeds.
- **Letter Spacing:** Set headlines and numbers to `-0.02em` tracking to keep dense financial aggregates compact and unified. Small operational labels (`label-sm`, `label-md`) use `+0.01em` tracking for crisp scannability.
- **Hierarchical Reading:** Primary metric figures take precedence with bold weights (`700`), followed by supporting micro-copy rendered in neutral gray `#667085` at regular weight (`400`).

## Layout & Spacing

This design system is built upon a 12-column responsive grid underpinned by an 8pt base layout rhythm.

- **Desktop (1024px and above):** 12-column grid, centered with max content container width of 1280px. Outer canvas margin is `margin-desktop` (3rem / 48px) with internal gutters of `gutter` (1.5rem / 24px).
- **Tablet (768px - 1023px):** 8-column layout with `margin` (2rem / 32px) margins and 1.5rem gutters.
- **Mobile (Below 768px):** 4-column layout with `margin-mobile` (1rem / 16px) margins and `gutter-mobile` (1rem / 16px) gutters. Complex portfolio grids fold vertically into full-width stacked cards.
- **Component Flow:** Internal spacing inside containers utilizes `space-md` (16px) for compact widgets and `space-lg` (24px) for prominent hero valuation cards. Vertical cadence between disparate sections maintains a clean `space-xl` (32px) distance.

## Elevation & Depth

Visual hierarchy uses a refined hybrid approach: **Tonal Stacking** paired with **Micro-Diffusion Ambient Shadows** and crisp hairline borders. Harsh drop shadows are intentionally omitted to avoid visual clutter around fine analytical data.

- **Layer 0 (Canvas Base):** Flat `#F8F9FC` background.
- **Layer 1 (Card & Content Level):** Pure `#FFFFFF` fill bounded by a hairline border (`1px solid #E5E8F0`) and an ambient shadow: `0 2px 8px -2px rgba(34, 39, 53, 0.04), 0 1px 4px -1px rgba(34, 39, 53, 0.02)`.
- **Layer 2 (Floating Controls & Hover States):** Lifted interactive cards and drop-down menus feature an expanded ambient shadow: `0 8px 24px -4px rgba(34, 39, 53, 0.08), 0 2px 6px -1px rgba(34, 39, 53, 0.03)` with a hairline outline in `#E5E8F0`.
- **Layer 3 (Overlays & Modals):** Pinned sheets and advisory modals utilize a concentrated depth plane: `0 16px 36px -8px rgba(34, 39, 53, 0.12), 0 4px 12px -2px rgba(34, 39, 53, 0.04)`, layered over a `#222735` backdrop scrim set to 30% opacity.
- **Tinted Highlights (Coach & Selected State):** When an element requires spotlight focus or advisory insight, elevation is replaced with surface tinting using `#EEF0FF` with a subtle primary border (`1px solid #5363E8`).

## Shapes

The shape vocabulary uses gentle, structural curves that project modern safety and approachability while preserving geometric discipline.

- **Base Radius (`0.5rem` / 8px):** Applied to form fields, nested tags, actionable list items, and segment pickers.
- **Medium Radius (`rounded-lg` - `1rem` / 16px):** Standard curvature for primary wealth cards, transactional containers, analytics modules, and primary call-to-action buttons.
- **Extended Radius (`rounded-xl` - `1.5rem` / 24px):** Reserved for modal sheets, sticky notification bars, and high-level portfolio overview banners.
- **Pill Exceptions:** Filter chips and status indicators use full pill radius (`9999px`) to cleanly differentiate actionable metadata from rectangular content cards.

## Components

### Buttons
- **Primary:** Solid `#5363E8` fill, white `#FFFFFF` text, `rounded-lg` (16px corner radius), 44px min-height. Hover: darker tint `#4352D0`. Focus: ring with 3px `#EEF0FF` offset.
- **Secondary:** `#EEF0FF` surface with `#5363E8` text, no border. Hover: `#E1E5FE`.
- **Ghost / Outline:** Transparent background, `1px solid #E5E8F0` border, `#222735` text. Hover: `#F8F9FC` background with `#222735` border.

### Input Fields & Controls
- **Inputs:** `#FFFFFF` background, `1px solid #E5E8F0` border, `rounded-md` (8px). Text in `#222735`, placeholder in `#667085`. On focus: `1.5px solid #5363E8` border with `#EEF0FF` focus ring.
- **Checkboxes & Radios:** Unchecked states feature `#FFFFFF` fill with `1.5px solid #E5E8F0`. Checked states transition to `#5363E8` with a crisp white check/dot icon.

### Cards & Data Containers
- **Default Card:** `#FFFFFF` surface, `1px solid #E5E8F0` border, `rounded-lg` (16px), Layer 1 ambient shadow.
- **Coach / Advisory Callout Card:** `#EEF0FF` surface, `1px solid rgba(83, 99, 232, 0.2)` border, `rounded-lg` (16px), containing a primary indigo icon indicator and dark charcoal guidance text.

### Chips & Filter Tags
- **Metric / Status Chips:** Pill-shaped (`rounded-full`), padding `4px 12px`. Unselected: `#F8F9FC` background with `#667085` text. Selected: `#5363E8` background with `#FFFFFF` text.
- **Accent Indicator:** Secondary Lavender `#B5ABF7` used for subtle categorization tags and secondary chart cohort legends.

### Lists & Ledger Tables
- Flat borderless cells grouped inside white `rounded-lg` cards. Individual rows separated by `1px solid #E5E8F0` hairline dividers. Hover state shifts row background to `#F8F9FC`. High-priority figures formatted in tabular bold charcoal text.