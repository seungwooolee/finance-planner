# dion. Stitch 통합 디자인 자료

세 개의 Stitch ZIP을 원본 경로와 파일 내용 그대로 합쳤습니다. 동일 경로·동일 내용의 DESIGN.md 3개는 1개로 정리했습니다. 입력 1/4 PC 화면 두 시안은 내용이 달라 모두 보존했습니다.

**이 패키지는 디자인 참고자료입니다. 완성된 앱이나 검증된 API 계약이 아닙니다.**

## 열어보는 순서

1. 압축을 완전히 해제한 뒤 `index.html`을 열어 화면별 HTML과 PNG를 확인합니다.
2. `REVIEW_NOTES.md`에서 누락·불일치·검증 범위를 확인합니다.
3. 구현 담당자에게 이 ZIP과 기존 저장소·질문 명세·계산 명세를 함께 전달하고 `CODEX_START_PROMPT.md`를 적용합니다.

## 원본 구성

| 원본 ZIP | 역할 | HTML | PNG | DESIGN.md |
|---|---|---:|---:|---:|
| stitch_dion.zip | 홈, 대표 질문, 저장 오류 | 12 | 12 | 1 |
| stitch_dion (1).zip | FAST 5개, 정보 보완, 로딩 | 7 | 2 | 1 |
| stitch_dion (2).zip | DEEP PC·모바일, 채택 모달, 상담 위젯 | 13 | 11 | 1 |
| 통합 후 | 서로 다른 원본 파일 58개 | 32 | 25 | 1 |

화면 전용 파일 기준입니다. 별도 모바일 FAST-01~05는 없으며, 32개 HTML 중 7개는 PNG가 없습니다. PC HTML의 모바일 대응 여부는 실행 검증하지 않았습니다.

## 추가한 안내 파일

- `index.html`: 외부 라이브러리 없이 열리는 로컬 화면 목록.
- `SCREEN_INVENTORY.csv`: 화면 역할·기기·원본 ZIP·파일 경로·해시 매핑.
- `RESOURCE_AUDIT.csv`: HTML의 src/href 참조와 외부 의존·임시 링크·파일 존재 여부.
- `manifest.json`: 원본 파일별 SHA-256 및 출처, 통합 결과.
- `REVIEW_NOTES.md`: 검토 결과와 구현 전 확인 사항.
- `CODEX_START_PROMPT.md`: 합의한 구현 원칙.

원본 디자인 문서는 `stitch_dion/blue_indigo_lavender_wealth_intelligence/DESIGN.md`에 있습니다. 원본 HTML은 Tailwind CDN·외부 폰트·외부 이미지에 의존하므로 인터넷 연결 없이 동일하게 표시된다고 보장할 수 없습니다.
